// models/comment_model.dart

class CommentModel {
  final int? id;
  final String postId;
  final String userName;
  final String userImage;
  final String comment;

  CommentModel({
    this.id,
    required this.postId,
    required this.userName,
    required this.userImage,
    required this.comment,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'postId': postId,
      'userName': userName,
      'userImage': userImage,
      'comment': comment,
    };
  }

  factory CommentModel.fromMap(Map<String, dynamic> map) {
    return CommentModel(
      id: map['id'],
      postId: map['postId'],
      userName: map['userName'],
      userImage: map['userImage'],
      comment: map['comment'],
    );
  }
}