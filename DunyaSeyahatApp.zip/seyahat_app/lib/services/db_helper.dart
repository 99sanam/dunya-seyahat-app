import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/post_model.dart';
import '../models/user_model.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDB();
    return _db!;
  }

  Future<Database> initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'seyahat_app.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE posts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            isim TEXT,
            sehir TEXT,
            resim TEXT,
            aciklama TEXT,
            etiket TEXT,
            konum TEXT,
            tarih TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE comments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            postid TEXT,
            username TEXT,
            userimage TEXT,
            comment TEXT
          )
        ''');

        await insertDefaultPostsInternal(db);
      },
    );
  }

  Future<void> insertDefaultPosts() async {
    final database = await db;
    await insertDefaultPostsInternal(database);
  }

  Future<void> insertDefaultPostsInternal(Database db) async {
    List<Map<String, dynamic>> defaultPosts = [
      {
        'isim': 'France',
        'sehir': 'Paris',
        'resim': 'assets/images/france.jpg',
        'aciklama': 'Eiffel Kulesi ile ünlü şehir.',
        'etiket': 'romantik, sanat',
        'konum': 'https://www.google.com/maps/place/Paris,+France',
        'tarih': '2023-04-15'
      },
      {
        'isim': 'Mexico',
        'sehir': 'Mexico City',
        'resim': 'assets/images/mexico.jpg',
        'aciklama': 'Zengin kültürüyle bilinir.',
        'etiket': 'kültürel, tarihi',
        'konum': 'https://www.google.com/maps/place/Mexico+City,+CDMX,+Mexico',
        'tarih': '2023-05-20'
      },
      {
        'isim': 'Bali',
        'sehir': 'Bali',
        'resim': 'assets/images/bali.jpg',
        'aciklama': 'Tropikal cennet.',
        'etiket': 'doğa, deniz',
        'konum': 'https://www.google.com/maps/place/Bali,+Indonesia',
        'tarih': '2023-06-10'
      },
      {
        'isim': 'India',
        'sehir': 'Agra',
        'resim': 'assets/images/india.jpg',
        'aciklama': 'Taj Mahal ile meşhur.',
        'etiket': 'tarih, mimari',
        'konum': 'https://www.google.com/maps/place/Taj+Mahal,+Agra,+Uttar+Pradesh,+India',
        'tarih': '2023-07-01'
      },
      {
        'isim': 'New York',
        'sehir': 'New York',
        'resim': 'assets/images/newyork.jpg',
        'aciklama': 'Özgürlük Heykeli ile tanınır.',
        'etiket': 'modern, metropol',
        'konum': 'https://www.google.com/maps/place/New+York,+NY,+USA',
        'tarih': '2023-08-18'
      },
      {
        'isim': 'Dubai',
        'sehir': 'Birleşik Arap Emirlikleri',
        'resim': 'assets/images/dubai.jpg',
        'aciklama': 'Gökdelenlerle dolu çöl şehri.',
        'etiket': 'modern, lüks',
        'konum': 'https://www.google.com/maps/place/Dubai,+United+Arab+Emirates',
        'tarih': '2023-09-05'
      },
    ];

    for (var post in defaultPosts) {
      await db.insert('posts', post);
    }
  }

  Future<int> insertPost(PostModel post) async {
    final database = await db;
    return await database.insert('posts', post.toMap());
  }

  Future<List<PostModel>> getAllPosts() async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query('posts');
    return List.generate(maps.length, (i) {
      return PostModel.fromMap(maps[i]);
    });
  }

  Future<List<PostModel>> searchPosts(String keyword) async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query(
      'posts',
      where: 'isim LIKE ?',
      whereArgs: ['%$keyword%'],
    );
    return List.generate(maps.length, (i) {
      return PostModel.fromMap(maps[i]);
    });
  }

  Future<Map<String, dynamic>?> getPlaceByName(String name) async {
    final database = await db;
    List<Map<String, dynamic>> results = await database.query(
      'posts',
      where: 'LOWER(isim) = ?',
      whereArgs: [name.toLowerCase()],
    );
    if (results.isNotEmpty) {
      return results.first;
    }
    return null;
  }

  Future<int> insertUser(UserModel user) async {
    final database = await db;
    return await database.insert('users', user.toMap());
  }

  Future<List<UserModel>> getAllUsers() async {
    final database = await db;
    final List<Map<String, dynamic>> maps = await database.query('users');
    return List.generate(maps.length, (i) {
      return UserModel.fromMap(maps[i]);
    });
  }

  Future<UserModel?> getUserByEmail(String email) async {
    final database = await db;
    List<Map<String, dynamic>> results = await database.query(
      'users',
      where: 'email = ?',
      whereArgs: [email],
    );
    if (results.isNotEmpty) {
      return UserModel.fromMap(results.first);
    }
    return null;
  }

  Future<int> insertComment(Map<String, dynamic> comment) async {
    final database = await db;
    return await database.insert('comments', comment);
  }

  Future<List<Map<String, dynamic>>> getCommentsByPostId(String postId) async {
    final database = await db;
    return await database.query(
      'comments',
      where: 'postid = ?',
      whereArgs: [postId],
      orderBy: 'id DESC',
    );
  }
}