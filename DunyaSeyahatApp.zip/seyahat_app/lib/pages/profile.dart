import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final TextEditingController nameController =
  TextEditingController(text: "Sanam Faizi");
  final TextEditingController emailController =
  TextEditingController(text: "sanam@example.com");
  final TextEditingController passwordController =
  TextEditingController(text: "*");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Profil",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60,
              backgroundColor: Colors.deepPurple.shade100,
              backgroundImage: const AssetImage('assets/images/girl.jpg'),
              onBackgroundImageError: (_, __) {},
              child: const Icon(Icons.person, size: 60, color: Colors.white),
            ),
            const SizedBox(height: 30),

            // İsim
            TextField(
              controller: nameController,
              style: const TextStyle(fontSize: 18),
              decoration: InputDecoration(
                labelText: 'Ad Soyad',
                labelStyle: const TextStyle(fontSize: 18),
                prefixIcon: const Icon(Icons.person),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),

            // E-posta
            TextField(
              controller: emailController,
              style: const TextStyle(fontSize: 18),
              decoration: InputDecoration(
                labelText: 'E-mail',
                labelStyle: const TextStyle(fontSize: 18),
                prefixIcon: const Icon(Icons.email),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 20),

            // Şifre
            TextField(
              controller: passwordController,
              obscureText: true,
              style: const TextStyle(fontSize: 18),
              decoration: InputDecoration(
                labelText: 'Şifre',
                labelStyle: const TextStyle(fontSize: 18),
                prefixIcon: const Icon(Icons.lock),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 35),

            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text("Ad: ${nameController.text}, Email: ${emailController.text}"),
                  ),
                );
              },
              icon: const Icon(Icons.save),
              label: const Text(
                "Güncelle",
                style: TextStyle(fontSize: 18),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}