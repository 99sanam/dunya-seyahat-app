import 'package:flutter/material.dart';
import 'package:seyahat_app/pages/home.dart';
import 'package:seyahat_app/pages/signup.dart';
import 'package:seyahat_app/services/db_helper.dart';
import 'package:seyahat_app/models/user_model.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController mailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> _loginUser() async {
    final email = mailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Lütfen tüm alanları doldurun.")),
      );
      return;
    }

    final db = DBHelper();
    final users = await db.getAllUsers();
    final matchedUser = users.firstWhere(
          (user) => user.email == email && user.password == password,
      orElse: () => UserModel(name: '', email: '', password: ''),
    );

    if (matchedUser.email.isNotEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Home()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("E-posta veya şifre yanlış.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(bottomRight: Radius.circular(180)),
              child: Image.asset(
                "assets/images/login.png",
                height: 350,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.only(left: 20.0),
              child: Text(
                "Giriş Yap",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
            _inputField("E-Posta", mailController),
            const SizedBox(height: 20),
            _inputField("Şifre", passwordController, isPassword: true),
            const SizedBox(height: 25),
            _loginButton(),
            const SizedBox(height: 30),
            _bottomText(),
          ],
        ),
      ),
    );
  }

  Widget _inputField(String label, TextEditingController controller, {bool isPassword = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 20, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white38),
              borderRadius: BorderRadius.circular(30),
            ),
            child: TextField(
              controller: controller,
              obscureText: isPassword,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              decoration: const InputDecoration(border: InputBorder.none),
            ),
          ),
        ],
      ),
    );
  }

  Widget _loginButton() {
    return GestureDetector(
      onTap: _loginUser,
      child: Container(
        height: 55,
        margin: const EdgeInsets.symmetric(horizontal: 20.0),
        decoration: BoxDecoration(
          color: const Color(0xfffc9502),
          borderRadius: BorderRadius.circular(30),
        ),
        child: const Center(
          child: Text(
            "Giriş Yap",
            style: TextStyle(color: Colors.black, fontSize: 22, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  Widget _bottomText() {
    return Column(
      children: [
        const Text(
          "Hesabınız yok mu?",
          style: TextStyle(color: Colors.white70, fontSize: 17),
        ),
        GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const SignUp()));
          },
          child: const Text(
            "Kayıt Ol",
            style: TextStyle(color: Color(0xfffea720), fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}