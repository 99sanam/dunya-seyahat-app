import 'package:flutter/material.dart';
import 'package:seyahat_app/pages/home.dart';
import 'package:seyahat_app/pages/login.dart';
import 'package:seyahat_app/services/db_helper.dart';
import 'package:seyahat_app/models/user_model.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> registerUser() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Lütfen tüm alanları doldurun.")),
      );
      return;
    }

    final db = DBHelper();
    final users = await db.getAllUsers();
    final alreadyExists = users.any((user) => user.email == email);

    if (alreadyExists) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.orangeAccent,
          content: Text("Bu e-posta ile kayıtlı bir kullanıcı zaten var."),
        ),
      );
    } else {
      final newUser = UserModel(name: name, email: email, password: password);
      await db.insertUser(newUser);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.green,
          content: Text("Kayıt başarıyla tamamlandı!", style: TextStyle(color: Colors.white)),
        ),
      );

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Home()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: const BorderRadius.only(bottomRight: Radius.circular(180)),
                        child: Image.asset(
                          "assets/images/signup.png",
                          height: 300,
                          width: MediaQuery.of(context).size.width,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Padding(
                        padding: EdgeInsets.only(left: 20),
                        child: Text(
                          "Kayıt Ol",
                          style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(height: 20),
                      _inputField("İsim", nameController),
                      _inputField("E-posta", emailController),
                      _inputField("Şifre", passwordController, isPassword: true),
                      const SizedBox(height: 30),
                      _signupButton(),
                      const SizedBox(height: 20),
                      _bottomText(),
                      const Spacer(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _inputField(String label, TextEditingController controller, {bool isPassword = false}) {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0, bottom: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 20, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            margin: const EdgeInsets.only(right: 20),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white38),
              borderRadius: BorderRadius.circular(30),
            ),
            child: TextField(
              controller: controller,
              obscureText: isPassword,
              cursorColor: Colors.white,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              decoration: const InputDecoration(border: InputBorder.none),
            ),
          ),
        ],
      ),
    );
  }

  Widget _signupButton() {
    return GestureDetector(
      onTap: registerUser,
      child: Container(
        height: 55,
        margin: const EdgeInsets.symmetric(horizontal: 20),
        decoration: BoxDecoration(
          color: const Color(0xfffc9502),
          borderRadius: BorderRadius.circular(30),
        ),
        child: const Center(
          child: Text("Kayıt Ol", style: TextStyle(color: Colors.black, fontSize: 22, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _bottomText() {
    return Column(
      children: [
        const Text("Zaten hesabınız var mı?", style: TextStyle(color: Colors.white70, fontSize: 17)),
        GestureDetector(
          onTap: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const Login()),
            );
          },
          child: const Text(
            "Giriş Yap",
            style: TextStyle(color: Color(0xfffea720), fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}