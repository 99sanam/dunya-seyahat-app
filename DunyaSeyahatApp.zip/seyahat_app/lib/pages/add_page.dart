
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import '../models/post_model.dart';
import '../services/db_helper.dart';

class AddPage extends StatefulWidget {
  const AddPage({super.key});

  @override
  State<AddPage> createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {
  final TextEditingController isimController = TextEditingController();
  final TextEditingController sehirController = TextEditingController();
  final TextEditingController aciklamaController = TextEditingController();
  final TextEditingController etiketController = TextEditingController();
  final TextEditingController locationController = TextEditingController();

  File? selectedImage;

  Future<void> pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile == null) return;

    final appDir = await getApplicationDocumentsDirectory();
    final fileName = basename(pickedFile.path);
    final savedImage = await File(pickedFile.path).copy('${appDir.path}/$fileName');

    setState(() {
      selectedImage = savedImage;
    });
  }

  Future<void> savePost(BuildContext context) async {
    if (isimController.text.isEmpty ||
        sehirController.text.isEmpty ||
        aciklamaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Lütfen tüm alanları doldurun.")),
      );
      return;
    }

    final imagePath = selectedImage?.path ?? 'assets/images/default.jpg';
    final currentDate = DateTime.now().toString().split(' ')[0]; // YYYY-MM-DD

    final post = PostModel(
      isim: isimController.text.trim(),
      sehir: sehirController.text.trim(),
      resim: imagePath,
      aciklama: aciklamaController.text.trim(),
      etiket: etiketController.text.trim(),
      konum: locationController.text.trim(),
      tarih: currentDate,
    );

    await DBHelper().insertPost(post);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Yer başarıyla eklendi.")),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Yeni Yer Ekle"),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              GestureDetector(
                onTap: pickImage,
                child: Container(
                  height: 180,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: selectedImage != null
                      ? Image.file(selectedImage!, fit: BoxFit.cover)
                      : const Center(child: Icon(Icons.camera_alt, size: 50)),
                ),
              ),
              const SizedBox(height: 20),
              _textField("Yer İsmi", isimController),
              _textField("Şehir", sehirController),
              _textField("Açıklama", aciklamaController, maxLines: 2),
              _textField("Etiketler (virgülle ayır)", etiketController),
              _textField("Google Maps Linki", locationController),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => savePost(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("Kaydet"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _textField(String label, TextEditingController controller, {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}