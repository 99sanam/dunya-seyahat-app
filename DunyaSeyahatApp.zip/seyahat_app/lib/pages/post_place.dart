
import 'package:flutter/material.dart';
import 'package:seyahat_app/services/db_helper.dart';
import 'package:seyahat_app/pages/comment.dart';
import 'package:url_launcher/url_launcher.dart';

class PostPlace extends StatefulWidget {
  final String place;
  const PostPlace({super.key, required this.place});

  @override
  State<PostPlace> createState() => _PostPlaceState();
}

class _PostPlaceState extends State<PostPlace> {
  Map<String, dynamic>? postData;
  List<String> ziyaretEdilenYerler = [];

  @override
  void initState() {
    super.initState();
    fetchPostData();
  }

  void fetchPostData() async {
    final data = await DBHelper().getPlaceByName(widget.place);
    setState(() {
      postData = data;
    });
  }

  Future<void> _launchMap(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Konum bağlantısı açılamadı")),
      );
    }
  }

  void _kaydetZiyaret() {
    setState(() {
      ziyaretEdilenYerler.add(postData!['isim']);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${postData!['isim']} için ziyaret kaydedildi.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (postData == null) {
      return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepPurple,
          title: const Text("Yükleniyor..."),
        ),
        body: const Center(
          child: CircularProgressIndicator(color: Colors.deepPurple),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: Text(postData!['isim'] ?? "Yer Detayı"),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                postData!['resim'] ?? "assets/images/default.jpg",
                width: double.infinity,
                height: 250,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 16),
              Text(
                "Şehir: ${postData!['sehir']}",
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                postData!['aciklama'] ?? "Açıklama bulunamadı.",
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      final url = postData!['konum'];
                      if (url == null || url.toString().trim().isEmpty || url.toString() == "null") {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Bu yer için geçerli bir konum bağlantısı yok.")),
                        );
                        return;
                      }
                      _launchMap(url);
                    },
                    icon: const Icon(Icons.map),
                    label: const Text("Konumu Aç"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                  ),
                  ElevatedButton.icon(
                    onPressed: _kaydetZiyaret,
                    icon: const Icon(Icons.location_on),
                    label: const Text("Ziyaret Et"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CommentPage(
                            postid: postData!['isim'],
                            username: "Misafir",
                            userimage: "assets/images/girl.jpg",
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.comment),
                    label: const Text("Yorumları Gör"),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}