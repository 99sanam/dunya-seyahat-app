class PostModel {
  final int? id;
  final String isim;
  final String sehir;
  final String resim;
  final String aciklama;
  final String etiket;
  final String konum;
  final String tarih;

  PostModel({
    this.id,
    required this.isim,
    required this.sehir,
    required this.resim,
    required this.aciklama,
    required this.etiket,
    required this.konum,
    required this.tarih,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'isim': isim,
      'sehir': sehir,
      'resim': resim,
      'aciklama': aciklama,
      'etiket': etiket,
      'konum': konum,
      'tarih': tarih,
    };
  }

  factory PostModel.fromMap(Map<String, dynamic> map) {
    return PostModel(
      id: map['id'],
      isim: map['isim'],
      sehir: map['sehir'],
      resim: map['resim'],
      aciklama: map['aciklama'],
      etiket: map['etiket'] ?? '',
      konum: map['konum'] ?? '',
      tarih: map['tarih'] ?? '',
    );
  }
}