
import 'package:flutter/material.dart';
import 'package:seyahat_app/pages/add_page.dart';
import 'package:seyahat_app/pages/comment.dart';
import 'package:seyahat_app/pages/home.dart';
import 'package:seyahat_app/pages/login.dart';
import 'package:seyahat_app/pages/signup.dart';
import 'package:seyahat_app/pages/top_places.dart';
import 'package:seyahat_app/pages/profile.dart';
import 'package:seyahat_app/pages/welcome_screen.dart';
import 'package:seyahat_app/services/db_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DBHelper().db;
  await DBHelper().insertDefaultPosts();
  runApp(const SeyahatUygulamasi());
}

class SeyahatUygulamasi extends StatelessWidget {
  const SeyahatUygulamasi({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Seyahat Uygulaması',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto', // Dilersen başka bir font family ekleyebiliriz
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          headlineLarge: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepPurple),
          bodyLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.black87),
          bodyMedium: TextStyle(fontSize: 16, color: Colors.black87),
          labelLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      initialRoute: '/welcome',
      routes: {
        '/welcome': (context) => const WelcomeScreen(),
        '/login': (context) => const Login(),
        '/signup': (context) => const SignUp(),
        '/home': (context) => const Home(),
        '/Profile': (context) => const ProfilePage(),
        '/add': (context) => const AddPage(),
        '/topplaces': (context) => const TopPlaces(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/comment') {
          final args = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (context) => CommentPage(
              postid: args['postid'],
              username: args['username'],
              userimage: args['userimage'],
            ),
          );
        }
        return null;
      },
    );
  }
}
