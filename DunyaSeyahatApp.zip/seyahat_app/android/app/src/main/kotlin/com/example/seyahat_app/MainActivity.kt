package com.example.seyahat_app  // bunu senin package adına göre değiştireceğiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}